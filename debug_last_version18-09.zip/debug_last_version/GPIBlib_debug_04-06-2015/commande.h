/********************************************
* commande.h
* Charles Plante
* 25 Juin 2015
*
* Ce fichier contient les commandes de base
* pour l'interface GPIB
***********************************************/

//Revision 1.0	25/06/2015	Commande de base pour effecuter une lecture
//Revision 1.1	26/06/2015	Ajout des commandes pour changer le nombre de NPLC
//Revision 1.2	29/06/2015	Ajout des commandes pour changer la r�solution

#ifndef COMMANDE_H
#define COMMANDE_H

#define CMD_GPIB_SET_VOLT_AC 		0x00		//Set the meter in voltage AC mode
#define CMD_GPIB_SET_VOLT_DC 		0x01		//Set the meter in voltage DC mode
#define CMD_GPIB_MEAS_VOLT_AC		0x02		//Take a read in voltage AC mode
#define CMD_GPIB_MEAS_VOLT_DC		0x03		//Take a read in voltage DC mode
#define CMD_GPIB_VOLT_DC_NPLC100	0x04		//Set in Volt DC NPLC at 100
#define CMD_GPIB_VOLT_DC_RANGE		0x05		//Switch the range of the meter
#define CMD_GPIB_VOLT_AC_RANGE		0x06		//Switch the range of the meter
#define CMD_GPIB_READ				0x07		//Take a read whit the current parameter

#endif

