/********************************************
* main.h
* Charles Plante-Veillette
* 25 Juin 2015
*
* Ce fichier contient la routine principale pour
* interpreter les commandes GPIB. Elle assure la
* communication entre le multimetre et le controlleur
***********************************************/

//Revision 1.0	25/06/2015	Commande de base pour effecuter une lecture
//Revision 1.1	26/06/2015	Ajout des commandes pour changer le nombre de NPLC
//Revision 1.2	29/06/2015	Ajout des commandes pour changer la r�solution


#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "gpiblib.h"
#include "i2c.h"
#include "commande.h"

/** buffers used for commands and output strings */
uchar buf[64], cmd_buf[64];

int main(void) {
	uchar b, e;

	DDRB &= 0x7F;

	char test = PINB;

	int ptrBuffer = 0;
	uchar buffer[20];

	// init gpib lines
	gpib_init();
	// init controller part - assign bus 
	gpib_controller_assign(0x00);
	gpib_set_partner(0x01);
	gpib_init_talk();

	// init I2C communication
	setup();
	slave_setSlave(0x55);	//set adress to 0x55

	//Wait for user to send some commands

	unsigned char wantedData = 0;

	while(1)
	{
		while(PINB <= 0x80);

		//_delay_ms(100);

		wantedData = slave_readByte();

		switch(wantedData)
		{
			case CMD_GPIB_SET_VOLT_AC:
				gpib_write("CONF:VOLT:AC", 0);
				break;

			case CMD_GPIB_SET_VOLT_DC:
				gpib_write("CONF:VOLT:DC", 0);
				break;

			case CMD_GPIB_MEAS_VOLT_AC:
				gpib_write("VOLT:AC:NPLC 100", 0);
				gpib_write("MEAS:VOLT:AC?", 0);
				gpib_init_receive();

				ptrBuffer = 0;
				// read the answer until EOI is detected (then e becomes true)
				do 
				{
					// gpib bus receive
					e = gpib_receive(&b);
					buffer[ptrBuffer] = b;
					ptrBuffer++;
				} while (!e);

				// send UNT and UNL commands (unlisten and untalk)
				// effect: all talker stop talking and all listeners stop listening
				cmd_buf[0] = G_CMD_UNT;
				gpib_cmd(cmd_buf, 1);
				cmd_buf[0] = G_CMD_UNL;
				gpib_cmd(cmd_buf, 1);

				//gpib_init();
				gpib_init_talk();

				slave_writeByte(ptrBuffer);
				slave_write(buffer, ptrBuffer);

				_delay_ms(2000);
				
				break;

			case CMD_GPIB_MEAS_VOLT_DC:

				gpib_write("VOLT:DC:NPLC 10", 0);
				//gpib_write("VOLT:DC:RANG 1.000000", 0);
				gpib_write("READ?", 0);
				gpib_init_receive();

				ptrBuffer = 0;
				// read the answer until EOI is detected (then e becomes true)
				do 
				{
					// gpib bus receive
					e = gpib_receive(&b);
					buffer[ptrBuffer] = b;
					ptrBuffer++;
				} while (!e);

				_delay_ms(2000);

				// send UNT and UNL commands (unlisten and untalk)
				// effect: all talker stop talking and all listeners stop listening
				cmd_buf[0] = G_CMD_UNT;
				gpib_cmd(cmd_buf, 1);
				cmd_buf[0] = G_CMD_UNL;
				gpib_cmd(cmd_buf, 1);

				//gpib_init();
				gpib_init_talk();

				slave_writeByte(ptrBuffer);
				slave_write(buffer, ptrBuffer);
				break;

			default:
				break;
				//Send some error code
				 
		}


	}

}

