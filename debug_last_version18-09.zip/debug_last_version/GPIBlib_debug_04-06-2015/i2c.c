#include "i2c.h"
#define uchar unsigned char



uchar master_writeByte(uchar adresse, uchar data)
{
	//---------------------CONDITION DE D�PART---------------

	TWCR = (1<<TWINT)|(1<<TWSTA)|(1<<TWEN);   		//Envoie la condition de d�part	
	while (!(TWCR & (1<<TWINT)));					//Quand le start est envoy�
	if((TWSR &=0xF8) != (TW_START)) //Echec de d�marrage
		return 1;
	//On formate l'adresse sur 7 bit et on met le LSB a 0
	adresse <<= 1;
	adresse &= 0xFE;
	
	TWDR = adresse;

	//---------------------ENVOIE L'ADRESSE------------------

	TWCR = (1<<TWINT) | (1<<TWEN);				//On transmet l'adresse	
	while (!(TWCR & (1<<TWINT)));				//On verifie la transmission et le ACK
		
	if (TW_STATUS != TW_MT_SLA_ACK)				//Test si l'adresse a �t� acquit�e pour envoie
	{
		TWCR = (1<<TWINT) | (1<<TWSTO) | (0<<TWEN);	// envoie un stop
		return 1;								// mauvaise adresse
	}

	
	//---------------------ENVOIE DES DONN�ES--------------

	TWDR = data;									//Place les donn�es dans le buffer

	TWCR = (1<<TWINT) | (1<<TWEN);					//On envoie les donn�es

	while (!(TWCR & (1<<TWINT)));					//On attend que les donn�e soit parties

	if ((TWSR & 0xF8) != TW_MT_DATA_ACK)			//Test si on a recu le ACK
		return 2;

	//---------------------FIN DES DONNEES------------------------

	TWCR = (0<<TWSTA) | (1<<TWINT) | (1<<TWEN) |( 1<<TWSTO);			//Send a STOP
	return 0;
}

uchar master_write(uchar adresse, uchar* data, uchar dataLength)
{
	//---------------------CONDITION DE D�PART---------------

	TWCR = (1<<TWINT)|(1<<TWSTA)|(1<<TWEN);   	//Envoie la condition de d�part	
	while (!(TWCR & (1<<TWINT)));				//Attend que le d�part soit confirm�
	if((TWSR &=0xF8) != TW_START) 				//Echec de d�marrage
		return 1;

	//On formate l'adresse sur 7 bit et on met le LSB a 0
	adresse <<= 1;
	adresse &= 0xFE;
	
	TWDR = adresse;

	//---------------------ENVOIE L'ADRESSE------------------

	TWCR = (1<<TWINT) | (1<<TWEN);				//On transmet l'adresse	
	while (!(TWCR & (1<<TWINT)));				//On verifie la transmission et le ACK
		
	if (TW_STATUS != TW_MT_SLA_ACK)				//Test si l'adresse a �t� acquit�e pour envoie
	{
		TWCR = (1<<TWINT) | (1<<TWSTO) | (0<<TWEN);	// envoie un stop
		return 1;								// mauvaise adresse
	}

	
	//---------------------ENVOIE DES DONN�ES--------------

	for(int i = 0; i < dataLength; i++)
	{
		TWDR = data[i];									//Place les donn�es dans le buffer

		TWCR = (1<<TWINT) | (1<<TWEN);					//On envoie les donn�es

		while (!(TWCR & (1<<TWINT)));					//On attend que les donn�e soit parties
	
		if ((TWSR & 0xF8) != TW_MT_DATA_ACK)			//Test si on a recu le ACK
			return 2;
	}

	//---------------------FIN DES DONNEES------------------------

	TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTO);			//Send a STOP
	return 0;
}

uchar master_read(uchar adresse, uchar* dataBuffer, uchar numberData)
{
	TWCR = (1<<TWINT)|(1<<TWSTA)|(1<<TWEN);   	//Envoie la condition de d�part	
	while (!(TWCR & (1<<TWINT)));				//Attend que le d�part soit confirm�							
	if((TWSR &=0xF8) != TW_START) 				//Echec de d�marrage
		return -1;

	//On formate l'adresse sur 7 bit et on met le LSB a 1
	adresse <<= 1;
	adresse &= 0xFE;
	adresse++;
	
	TWDR = adresse;

	TWCR = (1<<TWINT) | (1<<TWEN);				//On transmet l'adresse	
	while (!(TWCR & (1<<TWINT)));				//On verifie la transmission et le ACK
		
	if (TW_STATUS != TW_MR_SLA_ACK)				//Test si l'adresse a �t� acquit�e pour reception
	{
		TWCR = (1<<TWINT) | (1<<TWSTO) | (0<<TWEN);	// envoie un stop
		return -1;								// mauvaise adresse
	}
	
	for(int i = 0; i < numberData - 1; i++)
	{
		TWCR = (1<<TWINT) | (1<<TWEA) | (1<<TWEN);		//On accecpte les donn�es

		while (!(TWCR & (1<<TWINT)));					//On attend que les donn�es soit arrivees
	
		dataBuffer[i] = TWDR;									//Place les donn�es dans le buffer	
	
		if ((TWSR & 0xF8) != TW_MR_DATA_ACK)			//Test si on a envoy� le ACK
			return 2;
	}

	//-----------------------BLOC DE FIN-----------------------------	
	
	TWCR = (1<<TWINT) | (1<<TWEN) | (0<<TWEA);		//On accecpte les donn�es sans ACK

	while (!(TWCR & (1<<TWINT)));					//On attend que les donn�es soit arrivees
	
	dataBuffer[numberData - 1] = TWDR;					//Place les donn�es dans le buffer	
	
	if ((TWSR & 0xF8) != TW_MR_DATA_NACK)			//Test si on a envoy� le NACK (fin de trans)
		return 3;

	//----------------------FIN DES DONNEES------------------------

	TWCR = (0<<TWSTA) | (1<<TWINT)|(1<<TWEN)|(1<<TWSTO);			//Send a STOP
	return 0;

}

uchar master_readByte(uchar adresse)
{
	unsigned char data;

	TWCR = (1<<TWINT)|(1<<TWSTA)|(1<<TWEN);   	//Envoie la condition de d�part	
	while (!(TWCR & (1<<TWINT)));				//Attend que le d�part soit confirm�							
	if((TWSR &=0xF8) != TW_START) 				//Echec de d�marrage
		return 1;

	//On formate l'adresse sur 7 bit et on met le LSB a 1
	adresse <<= 1;
	adresse &= 0xFE;
	adresse++;
	
	TWDR = adresse;

	TWCR = (1<<TWINT) | (1<<TWEN);				//On transmet l'adresse	
	while (!(TWCR & (1<<TWINT)));				//On verifie la transmission et le ACK
		
	if (TW_STATUS != TW_MR_SLA_ACK)				//Test si l'adresse a �t� acquit�e pour reception
	{
		TWCR = (1<<TWINT) | (1<<TWSTO) | (0<<TWEN);	// envoie un stop
		return 1;								// mauvaise adresse
	}

	//-----------------------BLOC-----------------------------	
	
	TWCR = (1<<TWINT) | (1<<TWEN) | (0<<TWEA);		//On accecpte les donn�es sans ACK

	while (!(TWCR & (1<<TWINT)));					//On attend que les donn�es soit arrivees
	
	data = TWDR;									//Place les donn�es dans le buffer	
	
	if ((TWSR & 0xF8) != TW_MR_DATA_NACK)			//Test si on a envoy� le NACK (fin de trans)
		return 3;

	//----------------------FIN DES DONNEES------------------------

	TWCR = (0<<TWSTA) | (1<<TWINT)|(1<<TWEN)|(1<<TWSTO);			//Send a STOP
	return data;

}

uchar slave_readByte()
{
	unsigned char data;

	TWCR = (1<<TWEA) | (1<<TWEN);									//Active la reponse active a son adresse
	while (!(TWCR & (1<<TWINT))); 									//Attend la confirmation de reception de l'addresse
	if((TWSR &= 0xF8)  != TW_SR_SLA_ACK)	//Si adresse est confirm� continue
		return 1;

//-----------------RECEPTION DU BLOC ---------------------------

	TWCR = (1<<TWINT) | (1<<TWEA) | (1<<TWEN);	//On prepare la reception
	while (!(TWCR & (1<<TWINT))); 				//Attend la confirmation de reception
	if((TWSR &= 0xF8)  != TW_SR_DATA_ACK)		//V�rifie si on a confirm� les donn�es
		return 2;

	data = TWDR;

//-----------------FIN DE TRANSMISSION-----------

	TWCR = (1<<TWINT) | (1<<TWEA) | (1<<TWEN);	//On prepare la reception
	while (!(TWCR & (1<<TWINT)));				//Attend la confirmation de reception
	if((TWSR &=0xF8) == TW_SR_STOP)				//Si on recoit le symbole d'arret
	{
		TWCR = (1<<TWINT) | (1<<TWEA) | (1<<TWEN);
		return data;
	}
	else
		return 4;
}

uchar slave_read()
{
	uchar data = 0;

	TWCR = (1<<TWEA) | (1<<TWEN);				//Active la reponse active a son adresse
	while (!(TWCR & (1<<TWINT))); 				//Attend la confirmation de reception de l'addresse
	if((TWSR &= 0xF8)  != TW_SR_SLA_ACK)		//Si adresse est confirm� continue
		return 1;

//-----------------BLOC 1---------------------------

	TWCR = (1<<TWINT) | (1<<TWEA) | (1<<TWEN);	//On prepare la reception
	while (!(TWCR & (1<<TWINT))); 				//Attend la confirmation de reception
	if((TWSR &= 0xF8)  != TW_SR_DATA_ACK)		//V�rifie si on a confirm� les donn�es
		return 2;

	data = TWDR;								//Place les donn�es dans un buffer;

//-----------------BLOC 2---------------------------

	TWCR = (1<<TWINT) | (1<<TWEA) | (1<<TWEN);	//On prepare la reception
	while (!(TWCR & (1<<TWINT))); 				//Attend la confirmation de reception
	if((TWSR &= 0xF8)  != TW_SR_DATA_ACK)		//V�rifie si on a confirm� les donn�es
		return 3;

	data = TWDR;

//-----------------FIN DE TRANSMISSION-----------

	TWCR = (1<<TWINT) | (1<<TWEA) | (1<<TWEN);	//On prepare la reception
	while (!(TWCR & (1<<TWINT)));				//Attend la confirmation de reception
	if((TWSR &=0xF8) == TW_SR_STOP)				//Si on recoit le symbole d'arret
	{
		TWCR = (1<<TWINT) | (1<<TWEA) | (1<<TWEN);
		return data;
	}
	else
		return 4;
}

void slave_setSlave(char adresse)
{
	TWAR = adresse << 1;					//D�finit l'adresse du p�rif�rique;
	//if(active)
	//TWCR = (1<<TWEA) | (1<<TWEN);	//Active la reponse active a son adresse
}

uchar slave_writeByte(uchar data)
{
//-----------------RECEPTION DE L'ADRESSE-----------

	TWCR = (1<<TWEA) | (1<<TWEN);				//Active la reponse active a son adresse
	while (!(TWCR & (1<<TWINT))); 				//Attend la confirmation de reception de l'addresse
	if((TWSR &= 0xF8)  != TW_ST_SLA_ACK)		//Si adresse est confirm� continue
		return 1;
//-----------------ENVOIE DU BLOC-------------------

	TWDR = data;

	TWCR = (0<<TWEA) | (1<<TWINT) | (1<<TWEN);

	while (!(TWCR & (1<<TWINT))); 				//Attend la confirmation de reception du dernier octet
	if((TWSR &= 0xF8)  != TW_ST_DATA_NACK)		//Si confirmation que c'est le dernier octet
		return 3;

//-----------------FIN DE TRANSMISSION-----------

	TWCR = (1<<TWINT) | (1<<TWEA) | (1<<TWEN);	//On prepare la reception
	while (!(TWCR & (1<<TWINT)));				//Attend la confirmation de reception
	if((TWSR &=0xF8) == TW_SR_STOP)				//Si on recoit le symbole d'arret
		return 0;

    return 4;
}

uchar slave_write(uchar* data, uchar dataLength)
{

	//----------------- RECEPTION DE L'ADRESSE -----------

	TWCR = (1<<TWEA) | (1<<TWEN);				//Active la reponse active a son adresse
	while (!(TWCR & (1<<TWINT))); 				//Attend la confirmation de reception de l'addresse
	if((TWSR &= 0xF8)  != TW_ST_SLA_ACK)		//Si adresse est confirm� continue
		return 1;

	//----------------- PLACE LES DONNEES ET ENVOIE -----------

	for(int i = 0; i < dataLength - 1; i++)
	{	

		TWDR = data[i];

		TWCR = (1<<TWEA) | (1<<TWINT) | (1<<TWEN);

		while (!(TWCR & (1<<TWINT))); 				//Attend la confirmation de reception des donn�es
		if((TWSR &= 0xF8)  != TW_ST_DATA_ACK)		//Si adresse est confirm� continue
			return 2;
	}

	//----------------- ENVOIE LA DERNIERE DONNEES -----------
			
	TWDR = data[dataLength - 1];

	TWCR = (0<<TWEA) | (1<<TWINT) | (1<<TWEN);

	while (!(TWCR & (1<<TWINT))); 				//Attend la confirmation de reception du dernier octet
	if((TWSR &= 0xF8)  != TW_ST_DATA_NACK)		//Si confirmation que c'est le dernier octet
		return 3;

	TWCR = (1<<TWINT) | (1<<TWEA) | (1<<TWEN);	//On prepare la reception
	while (!(TWCR & (1<<TWINT)));				//Attend la confirmation de reception
	if((TWSR &=0xF8) == TW_SR_STOP)				//Si on recoit le symbole d'arret
		return 0;

    return 4;
}

void setup()
{
	power_twi_disable();
	DDRD |= (1<<1)|(1<<0);		// Les deux ports en sortie
	PORTD |= (1<<1)|(1<<0);		// Les deux ports � 1
	power_twi_enable();

	TWSR &= 0x0FC;
	TWSR |= 0x02;

	TWBR=0x040;
	TWCR|=(1<<TWEN);

}
