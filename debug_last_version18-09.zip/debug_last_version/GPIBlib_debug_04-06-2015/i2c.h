/********************************************
* i2c.h
* Charles Plante-Veillette
* 25 Juin 2015
*
* Contient les fonctions pour le I�C
***********************************************/

//Revision 1.0	25/06/2015	Commande de base pour effecuter une lecture
//Revision 1.1	26/06/2015	Ajout des commandes pour changer le nombre de NPLC
//Revision 1.2	29/06/2015	Ajout des commandes pour changer la r�solution#ifndef _I2C_

#ifndef _I2C_
#define _I2C_

#define F_CPU 16000000
#define uchar unsigned char

#include <avr/power.h>
#include <avr/io.h>
#include <util/twi.h>	
#include <util/delay.h>

uchar master_writeByte(uchar adresse, uchar data);
uchar master_write(uchar adresse, uchar* data, uchar dataLength);
uchar master_readByte(uchar adresse);
uchar master_read(uchar adresse, uchar* dataBuffer, uchar numberData);
uchar slave_readByte();
uchar slave_write(uchar* data, uchar dataLength);
uchar slave_writeByte(uchar data);
void slave_setSlave(char adresse);
void setup();

#endif
