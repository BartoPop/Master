/***********************************************************
Cr�er par : Charles Plante-Veillette
Date : 04/06/2015
Revision 1.0
***********************************************************/
#define F_CPU 16000000

#include <stdlib.h>
#include <stdio.h>
#include <avr/io.h>
#include <string.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#include "gpiblib.h"

#define release_bit(d,p,b) d &= ~_BV(b); p |= _BV(b);
#define assign_bit(d,p,b)  p &= ~_BV(b); d |= _BV(b); p &= ~_BV(b);

uchar cmd_buf[100];

typedef struct 
{
	uchar myaddress; /**< controller address,usually 0x00 */
	uchar partneraddress; /**< currently addressed partner device */
	uchar talks; /**< true while controller is talker */
	uchar partners[5]; /**< list of active partners */
} gpib_controller_t;

gpib_controller_t controller;

uchar _gpib_write(uchar *bytes, int length, uchar attention);

void gpib_init()
{
	//Le port A sert pour le DATA
	DDRA = 0x00;

	//Toutes les lignes de handshake sont des entr�es
	DDRC &= ~_BV(G_DAV); // DAV 
	DDRC &= ~_BV(G_EOI); // EOI 
	DDRC &= ~_BV(G_SRQ); // SRQ 
	DDRC &= ~_BV(G_ATN); // ATN  
	DDRB &= ~_BV(G_REN); // REN  
	DDRB &= ~_BV(G_IFC); // IFC  

	// init handshake lines
	assign_bit(DDRC, PORTC, G_NRFD);
	// not ready for data now
	release_bit(DDRC, PORTC, G_NDAC);
}

uchar gpib_cmd(uchar *bytes, int length) {
	// set attention arg true for commands
	return _gpib_write(bytes, length, (uchar) 1);
}

uchar gpib_write(uchar *bytes, int length) {
	// set attention arg false for ordinary strings
	return _gpib_write(bytes, length, (uchar) 0);
}

uchar gpib_receive(uchar* _byte) 
{
	uchar byte, eoi;

	if (controller.talks == 1) {
		*_byte = 0xff;
		return 0xff;
	}

	// handshake: set nrfd, means i am ready to receive some data
	release_bit(DDRC, PORTC, G_NRFD);
	assign_bit(DDRC, PORTC, G_NDAC);

	loop_until_bit_is_clear(PINC,G_DAV);

	// handshake: clear NRFD, means i am busy now to read data
	assign_bit(DDRC, PORTC, G_NRFD);
	// read data
	byte = PINA ^ 0xff;

	// handshake: set ndac, means i have completed/accepted the read
	release_bit(DDRC, PORTC, G_NDAC);

	loop_until_bit_is_set(PINC,G_DAV);

	// handshake: clear ndac (this is a prerequisite for receive next byte)
	assign_bit(DDRC, PORTC, G_NDAC);

	// check if last byte of transmission
	eoi = bit_is_clear(PINC,G_EOI);

	*_byte = byte;

	return eoi;
}

void queryPartners() {
	controller.partners[0] = 0x01;
	controller.partners[1] = 0x02;
	controller.partners[3] = 0x00; // end value is 0x00
}

void gpib_controller_assign(uchar address) 
{
	controller.myaddress = address;
	controller.talks = 0;
	controller.partneraddress = 0xFF; // init default active partner
	/** get all partners on bus by querying them */
	queryPartners();

	// set up initial state of bus
	assign_bit( DDRB, PORTB, G_IFC);
	_delay_ms(200);
	release_bit( DDRB, PORTB, G_IFC);
	// set up all devices for remote control
	assign_bit( DDRB, PORTB, G_REN);

	// DCL - device clear for all devices on bus
	cmd_buf[0] = G_CMD_DCL;
	gpib_cmd(cmd_buf, 1);
}

void gpib_controller_release(void) {
	// set up initial state of bus
	assign_bit( DDRB, PORTB, G_IFC);
	_delay_ms(200);
	release_bit( DDRB, PORTB, G_IFC);
	// set up all devices for local control
	release_bit( DDRB, PORTB, G_REN);
}


uchar _gpib_write(uchar *bytes, int length, uchar attention) {
	uchar c;
	int i;

	//uchar buf[64];

	// set talks state. This is used by ISR to recognize own talk
	// (controller must not talk to itself and must not take part in listener handshake when talking)
	controller.talks = 1;

	if (attention) {
		//uart_puts("\n\rgpib_controller_write()\n\r");
		// assign ATN for commands
		assign_bit( DDRC, PORTC, G_ATN);
	}

	if (length == 0) {
		// length==0 means this is a common C string, null-terminated.
		// then, length can be easily calculated
		length = strlen((char*) bytes);
	}
	// for debugging print out
	//	bytes[length]=0x00;
	//	if (length>1)
	//		sprintf( buf, "gpib_write: %s\n\r", (char *)bytes );
	//	else 
	//		sprintf( buf, "gpib_write: 0x%02x\n\r", bytes[0] );
	//	uart_puts((char*)buf);

	// release EOI during transmission
	release_bit(DDRC, PORTC, G_EOI);
	// release DAV, data not valid anymore
	release_bit(DDRC, PORTC, G_DAV);
	// release NRFD (just to be sure)
	release_bit(DDRC, PORTC, G_NRFD);

	// bytes[0] = 'a'
	// bytes[1] = 'b'
	// length = 2
	for (i = 0; i < length; i++) {

		// put data on bus
		c = bytes[i];
		//sprintf( buf, "char: %c\n\r", c );
		//uart_puts(buf);		

		release_bit(DDRC, PORTC, G_NDAC);
		//uart_puts("0");
		// wait for NDAC assign from all listeners

		loop_until_bit_is_clear(PINC,G_NDAC);

		DDRA = 0x00;
		if (c & 0x01) {
			assign_bit(DDRA, PORTA, PA0);
		} else {
			release_bit(DDRA, PORTA, PA0)
		}

		if (c & 0x02) {
			assign_bit(DDRA, PORTA, PA1)
		} else {
			release_bit(DDRA, PORTA, PA1);
		}

		if (c & 0x04) {
			assign_bit(DDRA, PORTA, PA2);
		} else {
			release_bit(DDRA, PORTA, PA2);
		}

		if (c & 0x08) {
			assign_bit(DDRA, PORTA, PA3);
		} else {
			release_bit(DDRA, PORTA, PA3);
		}

		if (c & 0x10) {
			assign_bit(DDRA, PORTA, PA4);
		} else {
			release_bit(DDRA, PORTA, PA4);
		}

		if (c & 0x20) {
			assign_bit(DDRA, PORTA, PA5);
		} 
		else 
		{
			release_bit(DDRA, PORTA, PA5);
		}

		if (c & 0x40){
			assign_bit(DDRA, PORTA, PA6);
		}else {
			release_bit(DDRA, PORTA, PA6);
		}

		if (c & 0x80){
			assign_bit(DDRA, PORTA, PA7);
		}else{
			release_bit(DDRA, PORTA, PA7);
			}

		// wait until listeners release NRFD
		//uart_puts("1");
		release_bit(DDRC, PORTC, G_NRFD);

		loop_until_bit_is_set(PINC,G_NRFD);

		// assign EOI during transmission of only last byte
		if ((i == length - 1) && !attention) {
			//uart_puts("\n\rE\n\r");
			assign_bit(DDRC, PORTC, G_EOI);
		}

		// assign DAV, data valid for listeners
		assign_bit(DDRC, PORTC, G_DAV);

		// wait for NDAC release
		//uart_puts("2");
		release_bit(DDRC, PORTC, G_NDAC);
		loop_until_bit_is_set(PINC, G_NDAC);

		// release DAV, data not valid anymore
		release_bit(DDRC, PORTC, G_DAV);

		// reset Port to all input
		DDRA = 0x00;

		//uart_puts("3\r\n");
	}

	if (attention) {
		// assign ATN for commands
		release_bit( DDRC, PORTC, G_ATN);
	}

	// clear talk state.Controller does not talk anymore.
	controller.talks = 0;

	return 0x00;
}

void gpib_set_partner(uchar address) {
	controller.partneraddress = address;
}
uchar gpib_get_partner(void) {
	return controller.partneraddress;
}
uchar gpib_get_address(void) {
	return controller.myaddress;
}

void gpib_init_talk()
{
	cmd_buf[0] = G_CMD_UNT;
	gpib_cmd(cmd_buf, 1);
	cmd_buf[0] = G_CMD_UNL;
	gpib_cmd(cmd_buf, 1);

	// set device (oszi) to listener mode
//	partnerAddress = address2ListenerAddress(gpib_get_partner());
	cmd_buf[0] = listenerAddress;
	gpib_cmd(cmd_buf, 1);

	// set myself (controller) to talker mode
//	partnerAddress = address2TalkerAddress(gpib_get_address());
	cmd_buf[0] = talkerAddress;
	gpib_cmd(cmd_buf, 1);
}

void gpib_init_receive()
{
	uchar Address = 0;
	// UNT and UNL
	cmd_buf[0] = G_CMD_UNT;
	gpib_cmd(cmd_buf, 1);
	cmd_buf[0] = G_CMD_UNL;
	gpib_cmd(cmd_buf, 1);

	// set myself (controller) to listener mode
	Address = address2ListenerAddress(gpib_get_address());
	cmd_buf[0] = Address;
	gpib_cmd(cmd_buf, 1);

	// set device (oszi) to talker mode
	Address = address2TalkerAddress(gpib_get_partner());
	cmd_buf[0] = Address;
	gpib_cmd(cmd_buf, 1);
}
