/***********************************************************
Cr�er par : Charles Plante-Veillette
Date : 04/06/2015
Revision 1.0
***********************************************************/

#ifndef GPIB_H
#define GPIB_H

typedef unsigned char uchar;
typedef unsigned int uint;
typedef unsigned long ulong;

#include <stdlib.h>
#include <stdio.h>
#include <avr/io.h>
#include <string.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>

/** Lignes pour le Handshake **/
#define G_DAV  PD2
#define G_NRFD PD3
#define G_NDAC PD5

/** Lignes pour le controle **/
#define G_EOI  PD4
#define G_SRQ  PD6
#define G_ATN  PD7
#define G_IFC  PB0
#define G_REN  PB1

/** Commandes GPIB **/
#define G_CMD_UNL 0x3f
#define G_CMD_UNT 0x5f
#define G_CMD_SPE 0x18
#define G_CMD_SPD 0x19
#define G_CMD_DCL 0x14


#define listenerAddress 0x21
#define talkerAddress	0x40
#define partnerAddress	0x01
#define controlAddress	0x00

/** calculate listener address from physical device address */
#define address2ListenerAddress(adr) (adr+0x20)
/** calculate talker address from physical device address */
#define address2TalkerAddress(adr) (adr+0x40)
/** calculate physical address from listener address */
#define listenerAddress2Address(adr) (adr-0x20)
/** calculate physical address from talker address */
#define TalkerAddress2Address(adr) (adr-0x40)

void gpib_init(void);
void gpib_controller_assign( uchar address );
void gpib_controller_release( void );
uchar gpib_cmd( uchar *bytes, int length );
void gpib_set_partner( uchar address );
uchar gpib_get_partner( void );
uchar gpib_get_address( void );
uchar gpib_receive( uchar *byte );
uchar gpib_write( uchar *bytes, int length );
void gpib_init_talk();
void gpib_init_receive();

#endif
