#ifndef _I2C_
#define _I2C_

#define uchar unsigned char

#include <avr/power.h>
#include <avr/io.h>
#include <util/twi.h>	
#include <util/delay.h>

char master_writeByte(char adresse, char data);
char master_write(char adresse, char* data, char dataLength);
char master_readByte(char adresse);
char master_read(char adresse, char* dataBuffer, char numberData);
char slave_readByte();
char slave_write(char* data, char dataLength);
char slave_writeByte(char data);
void slave_setSlave(char adresse);
void setup();

#endif
