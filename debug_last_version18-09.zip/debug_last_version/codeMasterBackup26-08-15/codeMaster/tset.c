#define F_CPU 16000000

#include <stdio.h>
#include <stdlib.h>
#include <avr/io.h>
#include <avr/power.h>
#include <avr/io.h>
#include <util/twi.h>
#include <util/delay.h>
#include <math.h>

#include "i2c.h"

#include "commande.h"


#define DDR_SPI DDRB

#define DD_SS  PB0
#define DD_SCK  PB1
#define DD_MOSI PB2
#define DD_MISO PB3

#define POS true
#define NEG false

#define bit_set(p,m) ((p) |= (m))

double real, wanted, delta, delta2;
char *real_ptr, *wanted_ptr, *delta_ptr;

char buffer[20];
char valeurInt[20];
char wantedValue[20];
char difference[20] = {'+', '1', '.', '9', '9', '9', '0', '0', '0', '0', 'E', '+', '0', '0', 0 };
char dataMultim[20] = {'a', 'b', 'c', '0', '0', '0', '0', '0', '0', '0', 'E', '+', '0', '0', 0 };
char option;

int dataLength;

int main() 
{

//Place les pin pour indiquer au multimetre d'entr� en lecture
DDRB |= 0xC0;
PORTB = 0;


//Initialisation des varaibles

real_ptr = buffer;
wanted_ptr = wantedValue;
delta_ptr = difference;


setup();



dataLength = 0;

wantedValue[16] = 0;


while(1)
{

_delay_ms(2000);
//Routine principale du processeur

PORTB |= 0x80;	//Multimetre
// Read what the meter's value 
master_writeByte(0x55, CMD_GPIB_MEAS_VOLT_DC);
_delay_ms(2);
dataLength = master_readByte(0x55);
_delay_ms(2);
master_read(0x55, buffer, dataLength);
_delay_ms(200);

PORTB &= 0x7F;	//Reset le multimetre
_delay_ms(200);

//* Print the received value to the screen 
buffer[dataLength]=0;

//real_ptr = test;

real = atof(real_ptr);
//sprintf(buffer, "%+1.8E", real);
  //*/

//On se synchronise avec l'affichage

char tempVal;

PORTB |= 0x40;
_delay_ms(200);

master_writeByte(0xAA, CHECK_USER_VALUE);
_delay_ms(2);

tempVal = master_readByte(0xAA);
_delay_ms(2);

master_writeByte(0xAA, CHECK_USER_VALUE);
_delay_ms(2);

tempVal = master_readByte(0xAA);
_delay_ms(2);
if(tempVal != 0)
{
//On lit la nouvelle valeur
//tempVal contient le nombre de charact�re de la r�ponse
master_read(0xAA, valeurInt, tempVal);
_delay_ms(2);
}


//On prend les nouvelles options

master_writeByte(0xAA, CHECK_USER_OPTION);
_delay_ms(2);
option = master_readByte(0xAA);
_delay_ms(2);


//On donne les nouvelles valeur a afficher

//multimetre
master_writeByte(0xAA, SET_MULTI_VALUE);
_delay_ms(2);

char varMix[30];
for(int f = 0; f < 15; f++)
{
	varMix[f] = buffer[f];
}
for(int g = 0; g < 15; g++)
{
	varMix[g+15] = valeurInt[g];
}

//on envoie la valeur du multimetre + la variable desire
master_write(0xAA, buffer, 30);
_delay_ms(100);


//Quand tout a �t� mis a jour, on envoie un signal de fin

master_writeByte(0xAA, END_OF_SYNC);
_delay_ms(2);

PORTB &= 0xBF;
//_delay_ms(200);
}
}
