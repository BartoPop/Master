/********************************************
* commande.h
* Charles Plante
* 25 Juin 2015
*
* Ce fichier contient les commandes de base
* pour l'interface GPIB
***********************************************/

#ifndef COMMANDE_H
#define COMMANDE_H

//Cette section d�finie les commandes pour controler le multimetre

#define CMD_GPIB_SET_VOLT_AC 	0x00
#define CMD_GPIB_SET_VOLT_DC 	0x01
#define CMD_GPIB_MEAS_VOLT_AC	0x02
#define CMD_GPIB_MEAS_VOLT_DC	0x03


//Cette partie d�finie les commandes interne de communication

#define CHECK_USER_VALUE		0x00
#define CHECK_USER_OPTION		0x01
#define SET_MULTI_VALUE			0x02
#define SET_DIFF_VALUE			0x03
#define END_OF_SYNC				0xFF


#endif

