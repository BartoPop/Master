#include <avr/power.h>
#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>

#define DDR_SPI DDRB

#define DD_SS	PB0
#define DD_SCK	PB1
#define DD_MOSI PB2
#define DD_MISO PB3

char SPI_Transmit(char cData);
void SPI_init(void);
