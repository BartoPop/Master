/**************************************************************************************************
---------------------------------------------------------------------------------------------------
	Copyright (c) 2004, Jonathan Bagg
	All rights reserved.

	 Redistribution and use in source and binary forms, with or without modification, are permitted 
	 provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice, this list of 
	  conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice, this list of 
	  conditions and the following disclaimer in the documentation and/or other materials provided 
	  with the distribution.
    * Neither the name of Jonathan Bagg nor the names of its contributors may be used to 
	  endorse or promote products derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR 
  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
  AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
  OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
---------------------------------------------------------------------------------------------------
   Project name : Infidigm AVR Drivers
   Processor	: ATMega16
   File name    : keypad.c
---------------------------------------------------------------------------------------------------
   Modifications: 

   Revision 1.0  2004/12/24 	Bagg
   - Cleaned up for release
   
---------------------------------------------------------------------------------------------------
   Created      : 22 November 2004                Author(s) : Jonathan Bagg
---------------------------------------------------------------------------------------------------
   4x4 KeyPad Driver
---------------------------------------------------------------------------------------------------
**************************************************************************************************/

#include <avr/io.h> 
#include "tim.h"
#include "keypad.h"

/**************************************************************************************************
*   INTERNAL GLOBAL VARIABLES
**************************************************************************************************/
static unsigned char press, result = NOKEY;

/**************************************************************************************************
*   pad_update(); - See 'keypad.h' Header file for Description
**************************************************************************************************/
void pad_update(void)
{
 static unsigned char pad_state, pad_timer, pad, filter, old;
  
 if (pad_state == 0) {
	DDRK = 0xF0;							//set to read KeyPad Rows
	PORTK = 0x00;
	pad_timer = timer_get(25);				//25mS timer for RC Debounce filters
	pad_state = 1;
 }
 else if (pad_state == 1 && timer_expired(pad_timer)) {
	pad = (PINK & 0x0F);					//read KeyPad Rows
	DDRK = 0x0F;							//set to read KeyPad Columns
	timer_reset(pad_timer, 25);
	pad_state = 2;
 }
 else if (pad_state == 2 && timer_expired(pad_timer)) {
	pad|= (PINK & 0xF0);				//read KeyPad Columns
	timer_release(pad_timer);
	pad_state = 0;
	if (pad == filter) { 				//Filter result (2 successful scans)
		if ((pad != NOKEY) && (old == NOKEY)) {
			result = pad;
			press = 1;					//Mark new key when butten has been released --> pressed
		}
		old = pad;
	}
	filter = pad;	
 }
}

/**************************************************************************************************
*   pad_read(); - See 'keypad.h' Header file for Description
**************************************************************************************************/
unsigned char pad_read(void) 
{
 return(result);
}

/**************************************************************************************************
*   pad_press(); - See 'keypad.h' Header file for Description
**************************************************************************************************/
unsigned char pad_press(void)
{
 unsigned char temp;
 
 temp = press;
 press = 0;
 return temp;
}
