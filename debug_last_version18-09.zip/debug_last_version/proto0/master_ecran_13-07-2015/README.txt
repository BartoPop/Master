****************************************************************
                      GU-7000 LARGE TEXT DEMO
****************************************************************
YOU MUST AGREE THIS TERMS AND CONDITIONS. THIS SOFTWARE IS
PROVIDED BY NORITAKE CO., INC "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR SORT (INCLUDING NEGLIGENCE OR
OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

----------------------------------------------------------------
ABOUT THIS DEMO
This project demonstrates how to use the Noritake_VFD_GU7000
code library to change the font size on the Noritake GU-7000
Vacuum Fluorescent Display (VFD) modules. You MUST download and
install the Noritake_VFD_GU7000 code library before running the
demo.

    http://www.noritake-elec.com

Please refer to the instructions on the download page and
"README" included with the Noritake_VFD_GU7000 code library for
information on how to install the Noritake_VFD_GU7000 code
library and demos.  This document assumes that you have already
configured the "config.h" file in the Noritake_VFD_GU7000 code
library as described in those documents.

For more information on the methods used in this document,
please refer to the method documentation in the
Noritake_VFD_GU7000 code library.

----------------------------------------------------------------
BEHAVIOR
This project displays 1x1 in the normal sized font, 2x2 in a
font that is twice as wide and twice as tall, and 3x2 in a font
that is three times as wide and twice as tall.

----------------------------------------------------------------
KEY POINTS
1) Reset and initialize the module with GU7000_reset() and
   GU7000_init().
3) Use GU7000_setFontSize() to set the font size relative to the
   default 1×1 font. The parameter 1 is the width and parameter
   2 is the height. The third parameter is used on GU-7900 to
   select the 8×16 dot font necessary to display CJK characters.

----------------------------------------------------------------
LISTING
#include "../src/config.h"
#include "../src/Noritake_VFD_GU7000.h"
Noritake_VFD_GU7000 vfd;
int main() {
    vfd.GU7000_reset();
    vfd.GU7000_init();
    vfd.GU7000_setFontSize(1,1,false);
    vfd.print("1x1");
    vfd.GU7000_setFontSize(2,2,false);
    vfd.print("2x2");
    vfd.GU7000_setFontSize(3,2,false);
    vfd.print("3x2");
}

----------------------------------------------------------------
E-M-0088-00 12/06/2011
----------------------------------------------------------------
SUPPORT

For further support, please contact:
    Noritake Co., Inc.
    2635 Clearbrook Dr 
    Arlington Heights, IL 60005 
    800-779-5846 
    847-439-9020
    support.ele@noritake.com

All rights reserved. © Noritake Co., Inc.