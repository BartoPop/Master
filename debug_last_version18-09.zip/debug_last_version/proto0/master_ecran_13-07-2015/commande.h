/********************************************
* commande.h
* Charles Plante
* 25 Juin 2015
*
* Ce fichier contient les commandes de base
* pour l'interface GPIB
***********************************************/

#ifndef COMMANDE_H
#define COMMANDE_H

#define CMD_GPIB_SET_VOLT_AC 	0x00
#define CMD_GPIB_SET_VOLT_DC 	0x01
#define CMD_GPIB_MEAS_VOLT_AC	0x02
#define CMD_GPIB_MEAS_VOLT_DC	0x03

#endif

