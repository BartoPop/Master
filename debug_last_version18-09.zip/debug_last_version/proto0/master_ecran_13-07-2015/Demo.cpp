//#include "../src/config.h"
//#include "../src/Noritake_VFD_GU7000.h"
#include <avr/power.h>
#include <avr/io.h>
#include <util/twi.h>	
#include <util/delay.h>
#include <stdlib.h>
//#include "i2c.h"
#include "spi.h"
//#include "commande.h"

//Noritake_VFD_GU7000 vfd;

#define DDR_SPI DDRB

#define DD_SS	PB0
#define DD_SCK	PB1
#define DD_MOSI PB2
#define DD_MISO PB3

#define POS true
#define NEG false

char buffer[20];
char wantedValue[20] = {'+', '1', '.', '0', '0', '0', '0', '0', '0', '0', '0', 'E', '+', '0', '0' };
char  difference[20] = {'+', '1', '.', '0', '0', '0', '0', '0', '0', '0', '0', '0', '-', '0', '1' };


char dataLength;

char MSB_DAC(bool positive, int value);


int main() 
{

//	vfd.GU7000_reset();
//    vfd.GU7000_init();
//    vfd.GU7000_setFontSize(1,1,false);
//	setup();

	DDRB = 0;

	SPI_init();

	/* Set the output for the opto-switch */
	DDRK = 0x07;
	PORTK = 0x04;

	char dataLength = 0;
/*
	vfd.GU7000_clearScreen();
	vfd.GU7000_setCursor(1, 0);
	for(int i = 0; i < dataLength; i++)
			vfd.print(wantedValue[i]);
  		

	while(1)
	{
		//* Send a value to the DAC 
		PORTB = 0x00;
		SPI_Transmit(MSB_DAC(true, dacValue));
		//SPI_Transmit(0xFF);
		SPI_Transmit(spiVarLSB_MAX);
		PORTB = 0x01;

		//* Read what the meter's value 
		master_writeByte(0x55, CMD_GPIB_MEAS_VOLT_DC);
		_delay_ms(2);
		dataLength = master_readByte(0x55);
		_delay_ms(2);
		master_read(0x55, buffer, dataLength);

		//* Print the received value to the screen 
	
		vfd.GU7000_setCursor(1, 0);
		
		for(int i = 0; i < dataLength; i++)
			vfd.print(buffer[i]);
 		
	}
	*/
}
//*
void print_difference()
{
	double real, wanted, delta;
	char *real_ptr, *wanted_ptr, *delta_ptr;
	real_ptr = buffer;
	wanted_ptr = wantedValue;
	delta_ptr = difference;

	real = atof(real_ptr);

/*	vfd.GU7000_setCursor(2, 0);
	for(int i = 0; i < 15; i++)
			vfd.print(difference[i]);
*/
}



/*	This fonction return the MSB byte to control the DAC
	It can convert positive or negative number from +127 to -128 */

char MSB_DAC(bool positive, int value)
{
	if(positive)
	{
		if(value == 0)
		{
			return 0x80;
		}
		else if(value <= 127)
		{
			value |= 0x80;
			return value;
		}
		else
			return 0xFF;	/* if the number is too big send max */
		
	}
	else
	{
		if(value == 0)
			return 0x80;
		
		else if(value <= 127)
		{
			value = 127 - (char)value;
			return value;
		}
		else
			return 0x80;	/* if the number is too big send zero */
	}
}
