#include "spi.h"

void SPI_init(void)
{
  DDRB = 0x07;
  SPCR = ((1<<SPE)|(1<<MSTR)|(1<<SPR0));  // SPI enable, Master, f/16
}

char SPI_Transmit(char cData)
{
   SPDR = cData;
   while(!(SPSR & (1<<SPIF)));
   return SPDR;
}
