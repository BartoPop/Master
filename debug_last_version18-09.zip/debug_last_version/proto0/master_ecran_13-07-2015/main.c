#include <stdio.h>
#include <stdlib.h>
#include <avr/interrupt.h>
#include <math.h>
#include <avr/power.h>
#include <avr/io.h>
#include <util/twi.h>	
#include <util/delay.h>
#include "../src/config.h"
#include "../src/Noritake_VFD_GU7000.h"
#include "commande.h"
#include "i2c.h"
#include <stdio.h>
#include <string.h>
#define touche_haut PINL & 0x02
#define touche_bas 	PINL & 0x80
#define touche_gauche PINL & 0x20
#define touche_droite PINL & 0x08

Noritake_VFD_GU7000 vfd;
int mem[100];
int state=9;
char toPrint[10]="";
char oldPrint[10]="";
int  defilMenu=0;
int oldDefil=-1;
char valeurAffiche[80]={'+',' ','0','0','0',' ','0','0','0','.','0',' ',' ',' ','m','V',' ','D','C',' ',
						'+',' ','0','0','0',' ','0','0','0','.','0',' ',' ',' ','m','V',' ','D','C',' ',
						' ','e','t','a','t','s',' ','e','t',' ','e','r','r',' ',' ',' ',' ',' ',' ',' ',
						' ','m','e','n','u','1',' ','m','e','n','u','2',' ','m','e','n','u','3',' ',' '}; //variable affich�e
int point=9;		//   0    1   2   3  4   5   6   7   8   9   10  11  12  13  14  15  16  17  18  19
int decimal=11;
bool signe=true;     
int unite=0;   
int decalage=1;
bool appuiX=false;
bool pointPos=true;
int posX=0;
int Menu1entree=0;
int Menu1son=0;
bool notPrint=false;
int defilsubMenu1X=0;           //variables g�rant le defillement
int oldDefilsubMenu1X=1;     
int defilsubMenu1Y=0;
int oldDefilsubMenu1Y=0;
int defilsubMenu2X=0;
int oldDefilsubMenu2X=1;
int defilsubMenu2Y=0;
int oldDefilsubMenu2Y=0;
int oldDefilsubMenu3Y=1;
int defilsubMenu3Y=0;
int debounceDelay=200;		//delai
int defilMenuEN=0;
char valeur[10];
int valeurLong=0;
bool reload=false;
bool enterPressed=false;
bool change=false;
bool changement=false;
char e='0';
char b;
bool stop=true;

signed char translate(signed char keyval)
    {
    	switch(keyval){
		case 17: 	return '1';
		case 18: 	return '2';
		case 20: 	return '3';
		case 24: 	return 'U';
		case 33:	return '4';
		case 34:	return '5';
		case 36: 	return '6';
		case 40: 	return 'A';
		case 65: 	return '7';
		case 66: 	return '8';
		case 68: 	return '9';
		case 72: 	return'X';
		case -124: 	return '-';
		case -126: 	return '0';
		case -127: 	return '.';
		case -120: 	return 'E';
		default : 	return '?';
		}

    };
struct optionMenuSaved{
int menu1En;
int menu1Son;
int menu2PL;
int menu2TA;
int menu2EC;
int menu3STO;
int menu3RCL;
int menu3mem;
};

void init(){
 	vfd.GU7000_reset();
    vfd.GU7000_init();
   	vfd.GU7000_clearScreen();
	vfd.print(valeurAffiche);

	defilsubMenu2X=0;
 	oldDefilsubMenu2X=1;
 	defilsubMenu2Y=0;
	oldDefilsubMenu2Y=0;
	defilsubMenu1X=0;
 	oldDefilsubMenu1X=1;
 	defilsubMenu1Y=0;
	oldDefilsubMenu1Y=0;

 	DDRB &= 0x00;
    PORTB |= 0xFF;

	DDRL &= 0x00;
	PORTL |= 0xFF;

	


}

void Zero(){
if(	
	valeurAffiche[2]=='0' &&
	valeurAffiche[3]=='0' &&
	valeurAffiche[4]=='0' &&
	valeurAffiche[6]=='0' &&
	valeurAffiche[7]=='0' &&
	valeurAffiche[8]=='0' &&
	valeurAffiche[10]=='0' )

{valeurAffiche[0]=' ';}


}
struct  optionMenuSaved optionSaved;  //options
void return_menu_principale(){
	state=9;
 	defilsubMenu2X=0;
 	oldDefilsubMenu2X=1;
 	defilsubMenu2Y=0;
	oldDefilsubMenu2Y=0;
	defilsubMenu1X=0;
 	oldDefilsubMenu1X=1;
 	defilsubMenu1Y=0;
	oldDefilsubMenu1Y=0;
	reload=true;
	defilMenu=0;
	oldDefil=-1;
}
void RAZ(){
optionSaved.menu1En=0;
optionSaved.menu1Son=0;
optionSaved.menu2PL=0;
optionSaved.menu2TA=0;
optionSaved.menu2EC=0;
optionSaved.menu3STO=0;
optionSaved.menu3RCL=0;
optionSaved.menu3mem=0;
return_menu_principale();
};
signed char get_key(){
    signed char key=0;
	DDRK=0xF0;
	PORTK=0x0F;

	signed char temp=0;
	if((PINK<0x0F)){
	
	switch (PINK & 0x0F){
	case 0x0E: 	DDRK=0x0F;
				PORTK|=0x0F;
				temp=PINK & 0xF0;		
				return key=temp+0x01;
				
				
	case 0x0D: 	DDRK=0x0F;
				PORTK|=0x0F;
				temp=PINK & 0xF0;				
				return key=temp+0x02;
				

	case 0x0B: DDRK=0x0F;
				PORTK|=0x0F;
				temp=PINK & 0xF0;					
				return key=temp+0x04;
				
							
	case 0x07: 	DDRK=0x0F;
				PORTK|=0x0F;
				temp=PINK & 0xF0;					
				return key=temp+0x08;
				
	}
	}
	
return ' ';    }


unsigned int convertCharToInteger(char *valeurAffiche){
char temp[7];
unsigned int val;
temp[0]=valeurAffiche[2];
temp[1]=valeurAffiche[3];
temp[2]=valeurAffiche[4];
temp[3]=valeurAffiche[6];
temp[4]=valeurAffiche[7];
temp[5]=valeurAffiche[8];
temp[6]=valeurAffiche[10];
val=atoi(temp);
return val;
}


void increaseValue(unsigned int val){
char temp[7];
int i=0;
int j=10;
bool stop=false;
if(val<9999999){
val++;
itoa(val,temp,10);

while(! stop){
i++;
if(temp[i]=='\0'){

	stop=true;
	}
	
	}

i--;
while(i>=0){

valeurAffiche[j]=temp[i];

j--;
if(j==9 || j==5){j--;}
i--;
}
}

}

void decreaseValue(unsigned int val){
char temp[7];
int i=0;
int j=10;
bool stop=false;
if(val>0){
val--;
itoa(val,temp,10);

while(! stop){
i++;
if(temp[i]=='\0'){

	stop=true;
	}
	
	}
if(val==9){
valeurAffiche[8]='0';
}
if(val==99){
valeurAffiche[7]='0';
}
if(val==999){
valeurAffiche[6]='0';
}
if(val==9999){
valeurAffiche[4]='0';
}
if(val==99999){
valeurAffiche[3]='0';
}
if(val==999999){
valeurAffiche[2]='0';
}
i--;
while(i>=0){

valeurAffiche[j]=temp[i];

j--;
if(j==9 || j==5){j--;}
i--;
}
}

}

void ecran_principale(){

//rafraichir l'affichage selon si appuis sur menu
if(reload){
				vfd.GU7000_clearScreen();
				vfd.print(valeurAffiche);
				reload=false;
				

} 
	char toPrint=translate(get_key());
	if(toPrint != '?' && toPrint!='A' && toPrint!='E' && decimal>2 && !appuiX){
	//appui sur une touche qui va changer l'affichage
   		if(toPrint=='-'){
		//modif signe
			if(signe){
			valeurAffiche[0]='-';
			signe=false;
			}
			else{
			valeurAffiche[0]='+';
			signe=true;
			}
			if (optionSaved.menu1En==1){
			changement=true;
			}
		}else{
		if(toPrint=='U'){
		//modif unit� (boucle en tre V mv et MiV)
			unite++;
			if(unite==3){unite=0;}
			if(unite==-1){unite=2;}
			switch(unite){
			case 0:valeurAffiche[14]='m';
					valeurAffiche[13]=' ';
					break;
			case 1:
				valeurAffiche[13]='m';
				valeurAffiche[14]='i';
				break;
			case 2:valeurAffiche[14]=' ';
					valeurAffiche[13]=' ';
					break;
			}
		if (optionSaved.menu1En==1){
			changement=true;
		}
			}
		
			else{
		if(toPrint=='.'){
		//changement de la decimale
		if(pointPos){
			valeurAffiche[5]=' ';
			valeurAffiche[9]='.';
			pointPos=false;			
			}
			else {
			valeurAffiche[9]=' ';
			valeurAffiche[5]='.';
			pointPos=true;	
			
			}
			if (optionSaved.menu1En==1){
			changement=true;
		}
		}
		else{
		

		
		if(toPrint=='X'){
		//appui sur X
			valeurAffiche[11]='X';
			appuiX=true;
			posX=10;
		}else {
		valeurAffiche[11]=toPrint;
		if (optionSaved.menu1En==1){
			changement=true;
		}
		switch(decimal){
		case 10:decimal--;break;
		case 9:decimal--;break;
		case 5:decimal--;break;
		case 1:decimal=10;break;
		}}
		decimal--;
		//changement de la valeur a afficher selon les modif apport�es
		valeurAffiche[2]=valeurAffiche[3];
		valeurAffiche[3]=valeurAffiche[4];
		valeurAffiche[4]=valeurAffiche[6];
		valeurAffiche[6]=valeurAffiche[7];
		valeurAffiche[7]=valeurAffiche[8];
		valeurAffiche[8]=valeurAffiche[10];
		valeurAffiche[10]=valeurAffiche[11];
		
		valeurAffiche[11]=' ';
		
		}}}
		vfd.GU7000_clearScreen();
		vfd.print(valeurAffiche);
	}
	if(toPrint=='A'){
	state=0;
	defilMenu=0;
	oldDefil=-1;

	}
	if(toPrint=='E'){
			valeurAffiche[19]='*';
			changement=true;
			if (optionSaved.menu1En==0){
			
		}

		}
		//incr�mentation de la valeur afficher 
		if (not(touche_haut) &&valeurAffiche[0]=='+' ){
			increaseValue(convertCharToInteger(valeurAffiche));
				vfd.GU7000_clearScreen();
		vfd.print(valeurAffiche);
		change=true;
		
			}
       
    if (not(touche_haut) &&valeurAffiche[0]=='-'){
			decreaseValue(convertCharToInteger(valeurAffiche));
			Zero();
				vfd.GU7000_clearScreen();
		vfd.print(valeurAffiche);
		change=true;
			}
			//decrementation de la valeur affich�e
    if ( !(touche_bas)&&valeurAffiche[0]=='+')
           	{ 
				decreaseValue(convertCharToInteger(valeurAffiche));
				Zero();
				vfd.GU7000_clearScreen();
				vfd.print(valeurAffiche);
				change=true;
			}
	if ( !(touche_bas)&&valeurAffiche[0]=='-' )
           	{ 
				increaseValue(convertCharToInteger(valeurAffiche));
				
				vfd.GU7000_clearScreen();
		vfd.print(valeurAffiche);
		change=true;
			}
				if ( !(touche_bas)&&valeurAffiche[0]==' ' &&!change)
           	{ 
				increaseValue(convertCharToInteger(valeurAffiche));
				valeurAffiche[0]='-';
				vfd.GU7000_clearScreen();
		vfd.print(valeurAffiche);
		change =false;
			}
			if (not(touche_haut) &&valeurAffiche[0]==' ' &&!change){
			valeurAffiche[0]='+';
				increaseValue(convertCharToInteger(valeurAffiche));
				vfd.GU7000_clearScreen();
		vfd.print(valeurAffiche);
		change =false;
			}	
	if (valeurAffiche[0]==' '){change=false;}

	if(appuiX){
	int i=1;
	
		if((not(PINB & 0x08))&&(posX!=10)){
			if(posX==8 ||posX==4){i=2;}
			valeurAffiche[posX]=valeurAffiche[posX+i];
			valeurAffiche[posX+i]='X';
			posX=posX+i;
			vfd.GU7000_clearScreen();
		vfd.print(valeurAffiche);

		}
		if((not(PINB & 0x02))&&(posX!=2)){
			if(posX==10||posX==6){i=2;}
			valeurAffiche[posX]=valeurAffiche[posX-i];
			valeurAffiche[posX-i]='X';
			posX=posX-i;
			vfd.GU7000_clearScreen();
		vfd.print(valeurAffiche);

		}
		
	}
	
			
}

void menu_principale(){

_delay_ms(150);
//defillement vertical
			if (not (touche_bas)){
				defilMenu++;
			}
       
    
    		if (not (touche_haut))
           	{ 
				defilMenu--;
			}


			if (translate(get_key())=='E'){
        		switch(defilMenu){
					case 0:
						state=1;
						break;
					case 1:
						state=2;
						break;
					case 2:
						state=3;
						break;
			}
				
			}
			
		defilMenu=defilMenu%3;
		if(defilMenu==-1){defilMenu=2;}
		if(not(oldDefil==defilMenu)){
			vfd.GU7000_clearScreen();
			switch(defilMenu){
				case 0:
					vfd.print("Menu 1");
					break;
				case 1:
					vfd.print("Menu 2");
					break;
				case 2:
					vfd.print("Menu 3");
					break;
			}
		oldDefil=defilMenu;
		
	  				
		}
		if(translate(get_key())=='A'){
	
				return_menu_principale();
				
			}}


void sous_menu_1(){
	
	
	if(translate(get_key())=='A'){
	
	return_menu_principale();
	}
	if(not (touche_haut)){
		defilsubMenu1X--;
		if(defilsubMenu1X<0){defilsubMenu1X=1;}
	}
	if(not (touche_bas)){
		defilsubMenu1X++;
		if(defilsubMenu1X>1){defilsubMenu1X=0;}
	}
	if(not (touche_gauche)){
		defilsubMenu1Y--;
		if(defilsubMenu1Y<0){defilsubMenu1Y=2;}
	}
	if(not (touche_droite)){
		defilsubMenu1Y++;
		if(defilsubMenu1Y>2){defilsubMenu1Y=0;}
	}

	/////entrer
	if(translate(get_key())=='E'){
	enterPressed=true;
	switch (defilsubMenu1Y){
		case 0:
			optionSaved.menu1En=defilsubMenu1X;
			break;
		case 1:
			optionSaved.menu1Son=defilsubMenu1X;
			break;
		case 2:RAZ();
		break;
			
			
			}}
			
			//Affichage suivant les cas
	if((defilsubMenu1Y!=oldDefilsubMenu1Y)){
		switch (defilsubMenu1Y){
			case 0:{
				vfd.GU7000_clearScreen();
				switch(optionSaved.menu1En){
						case 0:vfd.print("Avec enter    *");break;
						case 1:vfd.print("Sans enter    *");break;
						
				}
				break;
				
				}
			case 1:{
				vfd.GU7000_clearScreen();
				switch(optionSaved.menu1Son){
						case 0:vfd.print("Son Marche    *");break;
						case 1:vfd.print("Son arret    *");break;
						
				}
					
				
				
				break;
				}
			case 2:{
				vfd.GU7000_clearScreen();	
				vfd.print("RAZ");
				defilsubMenu1X=0;
				break;}
		}
		oldDefilsubMenu1Y=defilsubMenu1Y;
			
				
	}
	if(defilsubMenu1X!=oldDefilsubMenu1X||	enterPressed){
		switch (defilsubMenu1X){
			case 0:
				switch(defilsubMenu1Y){
					case 0:
						vfd.GU7000_clearScreen();	
							if(optionSaved.menu1En==0){
				vfd.print("Avec enter    *");
				}else {
					vfd.print("Avec enter");
				}
						break;
						
				
					case 1:
						vfd.GU7000_clearScreen();	
						if(optionSaved.menu1Son==0){
				vfd.print("son Marche    *");
				}else {
					vfd.print("son Marche");
				}
				
						break;
							
				}
				break;
			case 1:
				switch(defilsubMenu1Y){
					case 0:
						vfd.GU7000_clearScreen();	
							if(optionSaved.menu1En==1){
				vfd.print("Sans enter    *");
				}else {
					vfd.print("Sans enter");
				}
						
						break;
							
					case 1:
						vfd.GU7000_clearScreen();	
						if(optionSaved.menu1Son==1){
				vfd.print("son arret    *");
				}else {
					vfd.print("son arret");
				}
				
						
						break;
							
				}
				break;
		}
		oldDefilsubMenu1X=defilsubMenu1X;
			enterPressed=false;
	}
	
}
			
			
			



void sous_menu_2(){//fonction permettant d'interagir avec le sous menu 2
	
	
	if(translate(get_key())=='A'){
	
		return_menu_principale();
	}
	//touche pour le defillement horizontale
	if(not (touche_haut)){
		defilsubMenu2X--;
		if(defilsubMenu2X<0){defilsubMenu2X=5;}
	}
	if(not (touche_bas)){
		defilsubMenu2X++;
		if(defilsubMenu2X>5){defilsubMenu2X=0;}
	}
	//touche pour le defillement horizontale
	if(not (touche_gauche)){
		defilsubMenu2Y--;
		if(defilsubMenu2Y<0){defilsubMenu2Y=2;}
	}
	if(not (touche_droite)){
		defilsubMenu2Y++;
		if(defilsubMenu2Y>2){defilsubMenu2Y=0;}
	}
	//changement des options
		if(translate(get_key())=='E'){
	enterPressed=true;
	switch (defilsubMenu2Y){
		case 0:
			optionSaved.menu2PL=defilsubMenu2X;
			break;
		case 1:
			optionSaved.menu2TA=defilsubMenu2X;
			break;
		case 2:
			optionSaved.menu2EC=defilsubMenu2X;
			break;
			
			}
	
}
//Affichage suivant les cas
if((defilsubMenu2Y!=oldDefilsubMenu2Y)){
		switch (defilsubMenu2Y){
			case 0:{
				vfd.GU7000_clearScreen();	
				
				switch(optionSaved.menu2PL){
						case 0:vfd.print("PL200    *");break;
						case 1:vfd.print("PL100    *");break;
						case 2:vfd.print("PL50    *");break;
						case 3:vfd.print("PL10    *");break;
						case 4:vfd.print("PL5    *");break;
						case 5:vfd.print("PL1    *");break;
				}
				break;}
			case 1:{
				vfd.GU7000_clearScreen();	
				
				switch(optionSaved.menu2TA){
						case 0:vfd.print("TA Mi    *");break;
						case 1:vfd.print("TA 1s    *");break;
						case 2:vfd.print("TA 2s    *");break;
						case 3:vfd.print("TA 5s    *");break;
						case 4:vfd.print("TA 10s    *");break;
						case 5:vfd.print("TA 60s    *");break;
				}
				break;}
			case 2:{
				vfd.GU7000_clearScreen();	
				switch(optionSaved.menu2EC){
						case 0:vfd.print("EC Mi    *");break;
						case 1:vfd.print("Ec 1    *");break;
						case 2:vfd.print("Ec 2   *");break;
						case 3:vfd.print("Ec 3    *");break;
						case 4:vfd.print("Ec 4    *");break;
						case 5:vfd.print("Ec 5    *");break;
				}
				break;}
		}
		oldDefilsubMenu2Y=defilsubMenu2Y;
				
	}
	if(defilsubMenu2X!=oldDefilsubMenu2X|| enterPressed){
		switch (defilsubMenu2X){
			case 0:{
				switch(defilsubMenu2Y){
					case 0:
						vfd.GU7000_clearScreen();	
						if(optionSaved.menu2PL==0){

				vfd.print("PL200    *");
				}else {
					vfd.print("PL200");
				}
						break;
					case 1:
						vfd.GU7000_clearScreen();	
							if(optionSaved.menu2TA==0){

				vfd.print("TA Mi    *");
				}else {
					vfd.print("TA Mi");
				}
						
						break;
					case 2:
						vfd.GU7000_clearScreen();	
						if(optionSaved.menu2EC==0){

				vfd.print("EC Mi    *");
				}else {
					vfd.print("EC Mi");
				}
						
						break;
				
			}
			break;}
			case 1:{
				switch(defilsubMenu2Y){
					case 0:
						vfd.GU7000_clearScreen();	
					if(optionSaved.menu2PL==1){

				vfd.print("PL100    *");
				}else {
					vfd.print("PL100");
				}
						
						break;
					case 1:
						vfd.GU7000_clearScreen();	
						if(optionSaved.menu2TA==1){

				vfd.print("TA 1s    *");
				}else {
					vfd.print("TA 1s");
				}
						break;
					case 2:
						vfd.GU7000_clearScreen();	
							if(optionSaved.menu2EC==1){

				vfd.print("EC 1    *");
				}else {
					vfd.print("EC 1");
				}
					
						break;

			}break;}
				
				
			case 2:{switch(defilsubMenu2Y){
				case 0:
					vfd.GU7000_clearScreen();	
					if(optionSaved.menu2PL==2){

				vfd.print("PL50    *");
				}else {
					vfd.print("PL50");
				}
					break;
				case 1:
						vfd.GU7000_clearScreen();	
							if(optionSaved.menu2TA==2){

				vfd.print("TA 2s    *");
				}else {
					vfd.print("TA 2s");
				}
						break;
				case 2:
					vfd.GU7000_clearScreen();	
						if(optionSaved.menu2EC==2){

				vfd.print("EC 2    *");
				}else {
					vfd.print("EC 2");
				}
					break;
			}break;}
				
			case 3 :{switch(defilsubMenu2Y)
			{
				case 0:
					vfd.GU7000_clearScreen();	
					if(optionSaved.menu2PL==3){

				vfd.print("PL10    *");
				}else {
					vfd.print("PL10");
				}
					break;
				case 1:
						vfd.GU7000_clearScreen();	
							if(optionSaved.menu2TA==3){

				vfd.print("TA 5s    *");
				}else {
					vfd.print("TA 5s");
				}
						break;
				case 2:
					vfd.GU7000_clearScreen();	
					if(optionSaved.menu2EC==3){

				vfd.print("EC 3    *");
				}else {
					vfd.print("EC 3");
				}
			break;}break;}
			case 4:{switch(defilsubMenu2Y){
				case 0:
					vfd.GU7000_clearScreen();	
					if(optionSaved.menu2PL==4){

				vfd.print("PL5    *");
				}else {
					vfd.print("PL5");
				}
					break;
				case 1:
						vfd.GU7000_clearScreen();	
							if(optionSaved.menu2TA==4){

				vfd.print("TA 10s    *");
				}else {
					vfd.print("TA 10s");
				}
						break;
				case 2:
					vfd.GU7000_clearScreen();	
						if(optionSaved.menu2EC==4){

				vfd.print("EC 4    *");
				}else {
					vfd.print("EC 4");
				}
		break;}break;}
		
			case 5:{switch(defilsubMenu2Y){
				case 0:
					vfd.GU7000_clearScreen();	
				if(optionSaved.menu2PL==5){

				vfd.print("PL1    *");
				}else {
					vfd.print("PL1");
				}
					break;
				case 1:
						vfd.GU7000_clearScreen();	
							if(optionSaved.menu2TA==5){

				vfd.print("TA 60s    *");
				}else {
					vfd.print("TA 60s");
				}
						break;
				case 2:
					vfd.GU7000_clearScreen();	
						if(optionSaved.menu2EC==5){

				vfd.print("EC 5    *");
				}else {
					vfd.print("EC 5");
				}
				
				break;
				}
				break;
				}
			}
		oldDefilsubMenu2X=defilsubMenu2X;
			enterPressed=false;
	}


}


void sous_menu_3(){ //fonction permettant d'interagir avec le sous menu 3


	
	if(translate(get_key())=='A'){
	
	return_menu_principale();
	}
	if(not (touche_haut)){
		defilsubMenu1X--;
		if(defilsubMenu1X<0){defilsubMenu1X=1;}
	}
	if(not (touche_bas)){
		defilsubMenu1X++;
		if(defilsubMenu1X>1){defilsubMenu1X=0;}
	}
	if(not (touche_gauche)){
		defilsubMenu1Y--;
		if(defilsubMenu1Y<0){defilsubMenu1Y=2;}
	}
	if(not (touche_droite)){
		defilsubMenu1Y++;
		if(defilsubMenu1Y>2){defilsubMenu1Y=0;}
	}

	/////entrer
	if(translate(get_key())=='E'){
	enterPressed=true;
	switch (defilsubMenu1Y){
		case 0:
			optionSaved.menu1En=defilsubMenu1X;
			break;
		case 1:
			optionSaved.menu1Son=defilsubMenu1X;
			break;
		case 2:RAZ();
		break;
			
			
			}}
			
			
	if((defilsubMenu1Y!=oldDefilsubMenu1Y)){
		switch (defilsubMenu1Y){
			case 0:{
				vfd.GU7000_clearScreen();
				switch(optionSaved.menu1En){
						case 0:vfd.print("Avec enter    *");break;
						case 1:vfd.print("Sans enter    *");break;
						
				}
				break;
				
				}
			case 1:{
				vfd.GU7000_clearScreen();
				switch(optionSaved.menu1Son){
						case 0:vfd.print("Son Marche    *");break;
						case 1:vfd.print("Son arret    *");break;
						
				}
					
				
				
				break;
				}
			case 2:{
				vfd.GU7000_clearScreen();	
				vfd.print("RAZ");
				defilsubMenu1X=0;
				break;}
		}
		oldDefilsubMenu1Y=defilsubMenu1Y;
			
				
	}
	if(defilsubMenu1X!=oldDefilsubMenu1X||	enterPressed){
		switch (defilsubMenu1X){
			case 0:
				switch(defilsubMenu1Y){
					case 0:
						vfd.GU7000_clearScreen();	
							if(optionSaved.menu1En==0){
				vfd.print("Avec enter    *");
				}else {
					vfd.print("Avec enter");
				}
						break;
						
				
					case 1:
						vfd.GU7000_clearScreen();	
						if(optionSaved.menu1Son==0){
				vfd.print("son Marche    *");
				}else {
					vfd.print("son Marche");
				}
				
						break;
							
				}
				break;
			case 1:
				switch(defilsubMenu1Y){
					case 0:
						vfd.GU7000_clearScreen();	
							if(optionSaved.menu1En==1){
				vfd.print("Sans enter    *");
				}else {
					vfd.print("Sans enter");
				}
						
						break;
							
					case 1:
						vfd.GU7000_clearScreen();	
						if(optionSaved.menu1Son==1){
				vfd.print("son arret    *");
				}else {
					vfd.print("son arret");
				}
				
						
						break;
							
				}
				break;
		}
		oldDefilsubMenu1X=defilsubMenu1X;
			enterPressed=false;
	}

}


	double toDouble(const char* s) {
    unsigned long long int m = 1;
    double ret = 0;
    for (int i = 9; i >= 0; i--) {
        ret += (s[i] - '0') * m;
        m *= 10;
    }
    return ret;
}
char valeurBuffer[15]={'+','4','.','5','8','6','0','0','0','8','4','e','+','0','1'};
char charray[15];
void convertcharVolt(){
char tempChar[11]={valeurBuffer[3],valeurBuffer[4],valeurBuffer[5],valeurBuffer[6],valeurBuffer[7],valeurBuffer[8],valeurBuffer[9],valeurBuffer[10],'\0'};
char temp[4]={valeurBuffer[12],valeurBuffer[13],valeurBuffer[14],'\0'};
	int tempInt;

	sscanf(temp, "%d", &tempInt); //puissance
	double tempDouble,tempDouble1;
	 tempDouble1=(toDouble(tempChar))*0.00000001;

	tempDouble=tempDouble1+(valeurBuffer[1]-'0')*1;

		double res =tempDouble ;
		int i;


		if(tempInt>=0){
	for(i=0;i<tempInt;i++){
		res=res*10;

	}
		}
		else{

                    tempInt=0-tempInt;
               for(i=0;i<tempInt;i++){
		res=res/10;

	}}





sprintf(charray, "%9.9f", res);
int h=0;
for(h=12;h>0;h--){
       
    if(charray[h]=='0'||charray[h]=='\0'){charray[h]='\0';}
    else{break;}


}
if(charray[h]=='.'){charray[h]='\0';}



}
	void AfficherValeurBuffer(){
	//valeurAffiche[20]=valeurBuffer[0];
int unite=0;

char val[15];


char  charrayVolt[12];
convertcharVolt();
int longChaine=0,k=0;
while(charrayVolt[longChaine]!='\0'){
    val[longChaine]=charrayVolt[longChaine];

longChaine++;
};

int point=0;
for(k=0;k<=longChaine;k++){
    if(charrayVolt[k]=='.'){
                         point=1;
                         longChaine--;
                         break;}

}


if(val[0]=='0'){
        if(val[4]=='0' && val[2]=='0' &&val[3]=='0'){
            unite=2;
                    }else{
    unite=1;}

}
if(unite==2){
    valeurAffiche[33]='m';
    valeurAffiche[34]='i';
    valeurAffiche[22]=charrayVolt[5];
    valeurAffiche[23]=charrayVolt[6];
    valeurAffiche[24]=charrayVolt[7];
    valeurAffiche[25]='.';
    valeurAffiche[29]=' ';
    if(charrayVolt[8]!='\0'){valeurAffiche[26]=charrayVolt[8];}else{valeurAffiche[26]='0';}
    if(charrayVolt[9]!='\0'){valeurAffiche[27]=charrayVolt[9];}else{valeurAffiche[27]='0';}
    if(charrayVolt[10]!='\0'){valeurAffiche[28]=charrayVolt[10];}else{valeurAffiche[28]='0';}
   if(charrayVolt[11]!='\0'){valeurAffiche[30]=charrayVolt[11];}else{valeurAffiche[30]='0';}
valeurAffiche[32]=' ';
valeurAffiche[31]=' ';
}
if(unite==1){
    valeurAffiche[33]=' ';
    valeurAffiche[34]='m';
    valeurAffiche[22]=charrayVolt[2];
    valeurAffiche[23]=charrayVolt[3];
    valeurAffiche[24]=charrayVolt[4];
    valeurAffiche[25]='.';
    valeurAffiche[29]=' ';
    if(charrayVolt[5]!='\0'){valeurAffiche[26]=charrayVolt[5];}else{valeurAffiche[26]='0';}
    if(charrayVolt[6]!='\0'){valeurAffiche[27]=charrayVolt[6];}else{valeurAffiche[27]='0';}
    if(charrayVolt[7]!='\0'){valeurAffiche[28]=charrayVolt[7];}else{valeurAffiche[28]='0';}
   if(charrayVolt[8]!='\0'){valeurAffiche[30]=charrayVolt[8];}else{valeurAffiche[30]='0';}
valeurAffiche[32]=' ';
valeurAffiche[31]=' ';
}
if(unite==0){

    valeurAffiche[23]=' ';
    valeurAffiche[24]=' ';
    valeurAffiche[29]=' ';
    valeurAffiche[22]=charrayVolt[0];
    valeurAffiche[23]=charrayVolt[1];
    valeurAffiche[24]=charrayVolt[2];
    valeurAffiche[25]=charrayVolt[3];
    if(charrayVolt[4]!='\0'){valeurAffiche[26]=charrayVolt[4];}else{valeurAffiche[26]='0';}
    if(charrayVolt[5]!='\0'){valeurAffiche[27]=charrayVolt[5];}else{valeurAffiche[27]='0';}
    if(charrayVolt[6]!='\0'){valeurAffiche[28]=charrayVolt[6];}else{valeurAffiche[28]='0';}
    if(charrayVolt[7]!='\0'){valeurAffiche[29]=charrayVolt[7];}else{valeurAffiche[29]='0';}
   if(charrayVolt[8]!='\0'){valeurAffiche[30]=charrayVolt[8];}else{valeurAffiche[30]='0';}
   if(charrayVolt[9]!='\0'){valeurAffiche[31]=charrayVolt[9];}else{valeurAffiche[31]='0';}
 if(charrayVolt[10]!='\0'){valeurAffiche[32]=charrayVolt[10];}else{valeurAffiche[32]='0';}
}
	}


int main (void)   
{

	DDRB &= 0x7F; //Port pour la synchronisation

	init();
  	//AfficherValeurBuffer();

    setup();
	slave_setSlave(0xAA);
	
	while(1)
	{
		while(PINB <= 0x80);

	
		while(e!=0x00){
			e=slave_readByte();
	}

	while(!changement)
	{

	switch (state){
		case 9:
			ecran_principale();
			break;
		case 0:
			menu_principale();
			break;
		case 1:
			sous_menu_1();
			break;
		case 2:
			sous_menu_2();
			break;	
		case 3:
			sous_menu_3();
			break;

	}
	_delay_ms(debounceDelay);
	}
		slave_writeByte(0);
		while(stop){
		e=slave_readByte();
		switch(e){
			case 0x00:{
				if(changement){//condition avec entree
					slave_writeByte(20); //differnet de 0 donc j envoie le nombre de caractere
					slave_write(valeurAffiche,20);//variable utilisateur
				}else{
					slave_writeByte(0);
					break;
					}
				break;}
			case 0x02:{
				//b=slave_readByte();
				slave_read(valeurBuffer,30);

				//boucle pour recuperer la valeur du multim
				for(int f = 0; f < 20; f++)
				{
					valeurAffiche[f+20] = valeurBuffer[f];
				}
				vfd.GU7000_clearScreen();
				vfd.print(valeurAffiche);
				//AfficherValeurBuffer();
			//	vfd.GU7000_clearScreen();
			//	vfd.print(valeurAffiche);
				//val multi a afficher}
				break;}
			case 0x04:{
			//	b=slave_readByte();
				//difference
			//	AfficherValeurBuffer(valeurBuffer);}
				

				break;}
			case 0x01:
				 {
		
				slave_writeByte((char)optionSaved.menu2PL);
				break;}
			case 0xFF:{
				stop=false;  
				break;}
			
		}
	
		}
stop=true;
changement=false;
    }
	
    return 0;
}

